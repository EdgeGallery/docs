# How to run?

## Set the below env variables using the correct ip
```
export AK=QVUJMSUMgS0VZLS0tLS0
export SK=DXPb4sqElKhcHe07Kw5uorayETwId1JOjjOIRomRs5wyszoCR5R7AtVa28KT3lSc
export APPINSTID=5abe4782-2c70-4e47-9a4e-0ee3a1a0fd1f
export CA_CERT=./ca.crt
export MEP_IP=159.138.129.53
export MEP_APIGW_PORT=30443
export MEP_AUTH_ROUTE=mepauth
export ENABLE_WAIT=true
export CA_CERT_DOMAIN_NAME=edgegallery
```

## Run the token generator
```
./token_generator 
```
